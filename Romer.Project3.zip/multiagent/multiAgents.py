# multiAgents.py
# --------------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from util import manhattanDistance
from game import Directions
import random, util

from game import Agent

class ReflexAgent(Agent):
    """
    A reflex agent chooses an action at each choice point by examining
    its alternatives via a state evaluation function.

    The code below is provided as a guide.  You are welcome to change
    it in any way you see fit, so long as you don't touch our method
    headers.
    """


    def getAction(self, gameState):
        """
        You do not need to change this method, but you're welcome to.

        getAction chooses among the best options according to the evaluation function.

        Just like in the previous project, getAction takes a GameState and returns
        some Directions.X for some X in the set {NORTH, SOUTH, WEST, EAST, STOP}
        """
        # Collect legal moves and successor states
        legalMoves = gameState.getLegalActions()

        # Choose one of the best actions
        scores = [self.evaluationFunction(gameState, action) for action in legalMoves]
        bestScore = max(scores)
        bestIndices = [index for index in range(len(scores)) if scores[index] == bestScore]
        chosenIndex = random.choice(bestIndices) # Pick randomly among the best

        "Add more of your code here if you want to"

        return legalMoves[chosenIndex]

    def evaluationFunction(self, currentGameState, action):
        """
        Design a better evaluation function here.

        The evaluation function takes in the current and proposed successor
        GameStates (pacman.py) and returns a number, where higher numbers are better.

        The code below extracts some useful information from the state, like the
        remaining food (newFood) and Pacman position after moving (newPos).
        newScaredTimes holds the number of moves that each ghost will remain
        scared because of Pacman having eaten a power pellet.

        Print out these variables to see what you're getting, then combine them
        to create a masterful evaluation function.
        """
        # Useful information you can extract from a GameState (pacman.py)
        successorGameState = currentGameState.generatePacmanSuccessor(action)
        newPos = successorGameState.getPacmanPosition()
        newFood = successorGameState.getFood()
        newGhostStates = successorGameState.getGhostStates()
        newScaredTimes = [ghostState.scaredTimer for ghostState in newGhostStates]

        "*** YOUR CODE HERE ***"
        # Initialize score variable
        score = 0
        # Deduct points every time the PacMan stops
        if action == "Stop":
            score -= 50
        # If the state is a win, return the highest possible score
        if successorGameState.isWin():
            score = 100000
            return score
        # If PacMan hits a ghost that is not scared, return lowest possible score
        for ghost in newGhostStates:
            if newPos == ghost.getPosition() and ghost.scaredTimer is False:
                return -100000

        # Find the manhattan distance between the PacMan and all food items
        foodDistances = []
        for food in newFood.asList():
            foodDistances.append(manhattanDistance(newPos, food))
        # The closest food is the minimum distance between PacMan and a food item
        closestFood = min(foodDistances)
        # Add the inverse of the distance of closest food so that a closer food dot adds a higher number to the score
        # Multiply by 5 to add further score weight for finding food
        score += (1 / closestFood) * 5

        # Find the manhattan distance between PacMan and all ghosts
        ghostDistances = []
        for ghost in newGhostStates:
            ghostDistances.append(manhattanDistance(newPos, ghost.getPosition()))
        # Subtract points depending on how close the closest ghost is to PacMan
        closestGhost = min(ghostDistances)
        score -= closestGhost

        # Return the default score with the added score eval
        return successorGameState.getScore() + score

def scoreEvaluationFunction(currentGameState):
    """
    This default evaluation function just returns the score of the state.
    The score is the same one displayed in the Pacman GUI.

    This evaluation function is meant for use with adversarial search agents
    (not reflex agents).
    """
    return currentGameState.getScore()

class MultiAgentSearchAgent(Agent):
    """
    This class provides some common elements to all of your
    multi-agent searchers.  Any methods defined here will be available
    to the MinimaxPacmanAgent, AlphaBetaPacmanAgent & ExpectimaxPacmanAgent.

    You *do not* need to make any changes here, but you can if you want to
    add functionality to all your adversarial search agents.  Please do not
    remove anything, however.

    Note: this is an abstract class: one that should not be instantiated.  It's
    only partially specified, and designed to be extended.  Agent (game.py)
    is another abstract class.
    """

    def __init__(self, evalFn = 'scoreEvaluationFunction', depth = '2'):
        self.index = 0 # Pacman is always agent index 0
        self.evaluationFunction = util.lookup(evalFn, globals())
        self.depth = int(depth)

class MinimaxAgent(MultiAgentSearchAgent):
    """
    Your minimax agent (question 2)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action from the current gameState using self.depth
        and self.evaluationFunction.

        Here are some method calls that might be useful when implementing minimax.

        gameState.getLegalActions(agentIndex):
        Returns a list of legal actions for an agent
        agentIndex=0 means Pacman, ghosts are >= 1

        gameState.generateSuccessor(agentIndex, action):
        Returns the successor game state after an agent takes an action

        gameState.getNumAgents():
        Returns the total number of agents in the game

        gameState.isWin():
        Returns whether or not the game state is a winning state

        gameState.isLose():
        Returns whether or not the game state is a losing state
        """
        "*** YOUR CODE HERE ***"
        #util.raiseNotDefined()

        # Minimax algorithm
        def minimax(agent, depth, state):
            # Return evaluation function if the game is over
            if state.isLose() or state.isWin() or depth == self.depth + 1:
                return self.evaluationFunction(state)

            # PacMan's turn - maximize
            if agent == 0:
                actions = []
                # Check legal actions, call minimax, and pass turn to ghost
                for action in state.getLegalActions(0):
                    actions.append(minimax(1, depth, state.generateSuccessor(agent, action)))
                # Return the PacMan's maximized move
                return max(actions)

            # Ghost's turn - minimize
            else:
                # Next agent's index
                nextAgent = agent + 1
                # If the next agent is the only agent, it's PacMan's turn - advance the depth
                if gameState.getNumAgents() == nextAgent:
                    nextAgent = 0
                    depth += 1
                actions = []
                # Find all legal actions, call minimax, and pass to the next agent - could be a ghost or PacMan
                for action in state.getLegalActions(agent):
                    actions.append(minimax(nextAgent, depth, state.generateSuccessor(agent, action)))
                # Return the ghost's minimized move
                return min(actions)

        actions = {}
        # Create a dictionary to track various outcomes
        for action in gameState.getLegalActions(0):
            actions[action] = minimax(1, 1, gameState.generateSuccessor(0, action))
        # Return the maximized outcome
        return max(actions, key=actions.get)


class AlphaBetaAgent(MultiAgentSearchAgent):
    """
    Your minimax agent with alpha-beta pruning (question 3)
    """

    def getAction(self, gameState):
        """
        Returns the minimax action using self.depth and self.evaluationFunction
        """
        "*** YOUR CODE HERE ***"

        # Alpha-beta algorithm
        def alphabeta(agent, depth, state, alpha, beta):
            # Return evaluation function if the game is over
            if state.isLose() or state.isWin() or depth == self.depth + 1:
                return self.evaluationFunction(state)

            # PacMan's turn - maximize
            if agent == 0:
                # Track value, start low
                value = -99999
                for action in state.getLegalActions(0):
                    # Find the maximum value for each legal action
                    value = max(value, alphabeta(1, depth, state.generateSuccessor(agent, action), alpha, beta))
                    # Alpha will become the max between its current value and the found value
                    alpha = max(alpha, value)
                    # Pruning, if beta < alpha
                    if beta < alpha:
                        break
                # Return the maximized value
                return value

            # Ghost's turn - minimize
            else:
                # Find index of next agent
                nextAgent = agent + 1
                # If only 1 agent, PacMan's turn & advance depth
                if gameState.getNumAgents() == nextAgent:
                    nextAgent = 0
                    depth += 1
                # Find minimal value - start high
                value = 99999
                for action in state.getLegalActions(agent):
                    # For agent's legal actions, minimize the value
                    value = min(value, alphabeta(nextAgent, depth, state.generateSuccessor(agent, action), alpha, beta))
                    # Beta becomes the min between its current value and the found value
                    beta = min(beta, value)
                    # Pruning - if beta < alphas
                    if beta < alpha:
                        break
                # Return minimized value
                return value

        # Track actions and their values
        actions = {}
        # Start alpha low and beta high
        alpha = -99999
        beta = 99999
        # For all legal actions, run alpha-beta algorithm
        for action in gameState.getLegalActions(0):
            value = alphabeta(1, 1, gameState.generateSuccessor(0, action), alpha, beta)
            actions[action] = value
            if value > beta:
                return action
            alpha = max(value, alpha)

        # Return best action
        return max(actions, key=actions.get)

class ExpectimaxAgent(MultiAgentSearchAgent):
    """
      Your expectimax agent (question 4)
    """

    def getAction(self, gameState):
        """
        Returns the expectimax action using self.depth and self.evaluationFunction

        All ghosts should be modeled as choosing uniformly at random from their
        legal moves.
        """
        "*** YOUR CODE HERE ***"
        #util.raiseNotDefined()

        # Expectimax algorithm
        def expectimax(agent, depth, state):
            # Return evaluation function if the game is over
            if state.isLose() or state.isWin() or depth == self.depth + 1:
                return self.evaluationFunction(state)
            # PacMan's turn - maximize
            if agent == 0:
                actions = []
                for action in state.getLegalActions(0):
                    actions.append(expectimax(1, depth, state.generateSuccessor(agent, action)))
                return max(actions)
            # Ghost's turn - chance nodes - average of children's values
            else:
                # Find next agent
                nextAgent = agent + 1
                # If next agent is only agent, PacMan's turn, advance depth
                if state.getNumAgents() == nextAgent:
                    nextAgent = 0
                    depth += 1
                # Find value of all actions
                actions = []
                for action in state.getLegalActions(agent):
                    actions.append(expectimax(nextAgent, depth, state.generateSuccessor(agent, action)))
                # Return the average value of all possible actions
                return sum(actions) / float(len(state.getLegalActions(agent)))

        # Dictionary to store all legal actions and their values
        actions = {}
        for action in gameState.getLegalActions(0):
            actions[action] = expectimax(1, 1, gameState.generateSuccessor(0, action))
        # Return maximized action
        return max(actions, key=actions.get)

def betterEvaluationFunction(currentGameState):
    """
    Your extreme ghost-hunting, pellet-nabbing, food-gobbling, unstoppable
    evaluation function (question 5).

    DESCRIPTION:
    First, returns high score if PacMan wins/low score if PacMan loses
    Adds to score depending on location of closest food
    Subtracts to score depending on location of closest ghost
    """
    "*** YOUR CODE HERE ***"

    # Find position of PacMan, food, and ghosts
    position = currentGameState.getPacmanPosition()
    foods = currentGameState.getFood()
    ghosts = currentGameState.getGhostStates()

    # Return high score if game is won
    if currentGameState.isWin():
        return 100000
    # Return lowest score if game is lost
    for ghost in ghosts:
        if ghost.getPosition() == position and ghost.scaredTimer is False:
            return -100000

    # Initialize score
    score = 0
    foodDistances = []
    # Find all distances between PacMan and foods
    for food in foods.asList():
        foodDistances.append(manhattanDistance(position, food))
    # Find the distance of the closest food from PacMan
    closestFood = min(foodDistances)
    # Add the inverse distance to the score
    # Closer distance means higher score
    # Multiply by 10 for added weight
    score += (1/closestFood) * 10

    # Find the Manhattan distance between the PacMan and all ghosts
    ghostDistances = []
    for ghost in ghosts:
        ghostDistances.append(manhattanDistance(ghost.getPosition(), position))
    # Find the distance between PacMan and the closest ghost
    closestGhost = min(ghostDistances)
    # If the ghost is close to the PacMan, subtract from the score
    # Once again, inversed so that closer distance affects the score more
    if 1 >= closestGhost > 0:
        score -= (1/closestGhost)

    # Return the score
    return currentGameState.getScore() + score

# Abbreviation
better = betterEvaluationFunction
